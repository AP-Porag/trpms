import DataTable from '@/components/common/DataTable';
import { Button } from '@/components/ui/button';
import AppLayout from '@/layouts/app-layout.js';
import { Head, router, usePage } from '@inertiajs/react';
import { Plus } from 'lucide-react';
import { useEffect, useState } from 'react';
import { toast } from 'sonner';

const breadcrumbs = [
    {
        title: 'Leads',
        href: '/leads/index',
    },
];

export default function Index({ leads, meta, filters: initialFilters }) {
    const { flash } = usePage().props;

    useEffect(() => {
        if (flash?.success) {
            toast.success(flash.success);
        }
    }, [flash]);

    const [filters, setFilters] = useState({
        search: initialFilters.search || '',
        status: initialFilters.status || 'all',
        perPage: initialFilters.perPage || 5,
        page: meta.current_page || 1,
    });

    useEffect(() => {
        // Push new filters to URL and reload data
        router.get(route('leads.index'), filters, {
            preserveState: true,
            replace: true,
            preserveScroll: true,
        });
    }, [filters.search, filters.status, filters.perPage, filters.page]);

    const columns = [
        { key: 'name', label: 'Name' },
        { key: 'company_name', label: 'Company' },
        { key: 'mpc', label: 'MPC' },
        // {
        //     key: 'email',
        //     label: 'Email',
        //     render: (row) => <span className="block w-48 truncate">{row.email}</span>,
        // },
        // {
        //     key: 'phone',
        //     label: 'Phone',
        //     render: (row) => <span className="block w-48 truncate">{row.phone}</span>,
        // },
        // {
        //     key: 'client_type',
        //     label: 'Type',
        //     render: (row) => <span className="block w-48 truncate capitalize">{row.client_type}</span>,
        // },
        {
            key: 'status',
            label: 'Status',
            render: (row) => {
                const statusStyles = {
                    1: 'bg-green-100 text-green-800',
                    0: 'bg-red-100 text-red-800',
                };
                return (
                    <span className={`rounded px-2 py-1 text-xs font-medium ${statusStyles[row.status] || 'bg-gray-100 text-gray-800'}`}>
                        {row.status === 1 ? 'Active' : 'Inactive'}
                    </span>
                );
            },
        },
    ];

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Leads" />
            <div className="p-4">
                <div className="my-4 flex items-center justify-between">
                    <h1 className="text-2xl font-bold">Leads</h1>
                    <Button onClick={() => router.visit(route('leads.create'))} className="cursor-pointer bg-black text-white hover:bg-gray-800">
                        <Plus className="mr-2" /> Create Lead
                    </Button>
                </div>
                <DataTable
                    data={leads}
                    columns={columns}
                    meta={{
                        from: meta.from,
                        to: meta.to,
                        total: meta.total,
                        current_page: meta.current_page,
                        last_page: meta.last_page,
                        searchPlaceholderText: meta.searchPlaceholderText,
                    }}
                    actions={{
                        view: true,
                        edit: true,
                        delete: true,
                        search_filter: true,
                        status_filter: true,
                        per_page_filter: true,
                    }}
                    baseRoute="leads"
                    filters={filters}
                    onFilterChange={setFilters}
                />
            </div>
        </AppLayout>
    );
}
