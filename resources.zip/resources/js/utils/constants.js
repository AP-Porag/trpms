export const USER_ROLE = {
    ADMIN: 'admin',
    USER: 'user',
};

export const STATUS = {
    ACTIVE: 1,
    INACTIVE: 0,
};

export const FLASH = {
    SUCCESS: 'success',
    ERROR: 'error',
};

/*
|--------------------------------------------------------------------------
| Client Types
|--------------------------------------------------------------------------
*/

export const CLIENT_TYPE = {
    RETAINER: 'retainer',
    CONTINGENCY: 'contingency',
};

export const RATING = {
    RATING_A: 'A',
    RATING_B: 'B',
    RATING_C: 'C',
};

/*
|--------------------------------------------------------------------------
| Client Categories
|--------------------------------------------------------------------------
*/

export const CLIENT_CATEGORY = {
    CLIENT: 'client',
    PROSPECT: 'prospect',
    TARGET_ACCOUNT: 'target_account',
};

/*
|--------------------------------------------------------------------------
| Fee Types
|--------------------------------------------------------------------------
*/

export const JOB_FEE_TYPE = {
    PERCENTAGE: 'percentage',
    FIXED: 'fixed',
    RETAINED: 'retained',
};

export const PLACEMENT_INVOICE_STATUS = {
    NOT_INVOICED: 'not_invoiced',
    INVOICED: 'invoiced',
    PAID: 'paid',
};

export const INVOICE_STATUS = {
    ISSUED: 'issued',
    PAID: 'paid',
    CANCELED: 'canceled',
};

/*
|--------------------------------------------------------------------------
| Job Constant
|--------------------------------------------------------------------------
*/

export const PRIORITY = {
    HIGH: 'high',
    MEDIUM: 'medium',
    LOW: 'low',
};
