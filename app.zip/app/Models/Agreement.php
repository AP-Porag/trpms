<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Agreement extends BaseModel
{

    use HasFactory;
    protected $fillable = [
        'client_id',
        'file_path',
        'original_name',
        'signed_date',
        'agreement_type'
    ];

    public function client()
    {
        return $this->belongsTo(Client::class, 'client_id');
    }
}
