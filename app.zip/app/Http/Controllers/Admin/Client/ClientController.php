<?php

namespace App\Http\Controllers\Admin\Client;

use App\Http\Controllers\BaseController;
use App\Http\Requests\Client\ClientRequest;
use App\Models\Client;
use App\Models\Department;
use App\Models\Industry;
use App\Services\Client\ClientService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ClientController extends BaseController
{
    public function __construct(protected ClientService $service) {}


    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return Inertia::render('admin/client/index', $this->service->list($request));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

        return Inertia::render('admin/client/create', [
            'industries' => Industry::select('id', 'name')->get(),
            'departments' => Department::select('id', 'name')->get(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(ClientRequest $request)
    {

        $this->service->create($request);
        return redirect()
            ->route('clients.index')
            ->with('success', 'Client created successfully.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $client = Client::findOrFail($id);


        $data = $this->service->detail($client);

        return Inertia::render('admin/client/show', $data);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Client $client)
    {
        return inertia('admin/client/edit', [
            'client' => $client->load('departments:id,name'),
            'agreement' => $client->agreements()->first(),
            'industries' => Industry::select('id', 'name')->get(),
            'departments' => Department::select('id', 'name')->get(),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(ClientRequest $request, Client $client)
    {
        $this->service->update($client, $request);

        return redirect()
            ->route('clients.index')
            ->with('success', 'Client updated successfully.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Client $client)
    {
        $this->service->delete($client->id);
    }

    public function setHiringManager(Request $request, int $id)
    {
        $request->validate([
            'contact_id' => ['required', 'integer'],
        ]);

        $this->service->setHiringManager($id, $request->contact_id);

        return back()->with('success', 'Hiring manager updated');
    }
}
